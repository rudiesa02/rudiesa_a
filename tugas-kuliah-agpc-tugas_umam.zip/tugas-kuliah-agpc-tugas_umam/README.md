# ALGORITMA GENETIKA untuk PENGOLAHAN CITRA
Tugas 5 mata kuliah Kecerdasan Buatan

**IMPORTANT** Project ini hasil forking dari [GARI](https://github.com/ahmedfgad/GARI) oleh [Ahmed Gad](https://github.com/ahmedfgad) dengan sedikit penyesuaian

* Nama: Muhammad Chairul Umam
* NIM: 2170233001